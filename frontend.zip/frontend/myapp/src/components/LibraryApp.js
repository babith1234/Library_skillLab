// LibraryApp.js
// import React, { useState } from "react";
// import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
// import AddBook from "./AddBook"; // Correct the import path
// import Home from "./Home";

// const LibraryApp = () => {
//   const [items, setItems] = useState([]); // Lift the state up

//   return (
//     <Router>
//       <Switch>
//         <Route path="/addbook">
//           <AddBook />
//         </Route>
//         <Route path="/home">
//           <Home items={items} />
//         </Route>
//       </Switch>
//     </Router>
//   );
// };

// export default LibraryApp;
